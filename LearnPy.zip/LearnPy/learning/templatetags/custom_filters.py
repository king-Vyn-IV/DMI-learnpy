from django import template

register = template.Library()

@register.filter
def get_item(dictionary, key):
    if dictionary is None:
        return None  # Return None or an appropriate default value
    return dictionary.get(key)
