from django.db import models
from django.contrib.auth.models import User

# Category model for organizing tutorials
class Category(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()

    def __str__(self):
        return self.name


# Tutorial model with reference to Category
class Tutorial(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    content = models.TextField()  # This will hold the main content of the tutorial
    resources = models.URLField(blank=True, null=True)  # Link to external resources
    category = models.ForeignKey(Category, related_name='tutorials', on_delete=models.CASCADE)
    difficulty_level = models.CharField(max_length=50, choices=[('Beginner', 'Beginner'), 
                                                               ('Intermediate', 'Intermediate'), 
                                                               ('Advanced', 'Advanced')])
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


# Quiz model to store questions for each tutorial
class Quiz(models.Model):
    tutorial = models.ForeignKey(Tutorial, related_name='quizzes', on_delete=models.CASCADE)
    question = models.CharField(max_length=500)
    answer = models.TextField()
    option_a = models.CharField(max_length=200)
    option_b = models.CharField(max_length=200)
    option_c = models.CharField(max_length=200)
    option_d = models.CharField(max_length=200)
    correct_option = models.CharField(max_length=255) 

    def __str__(self):
        return f"Quiz for {self.tutorial.title}"


# UserProgress model to track user progress on tutorials
class UserProgress(models.Model):
    user = models.ForeignKey(User, related_name='progress', on_delete=models.CASCADE)
    tutorial = models.ForeignKey(Tutorial, related_name='user_progress', on_delete=models.CASCADE)
    completed = models.BooleanField(default=False)
    score = models.IntegerField(default=0)

    def __str__(self):
        return f"Progress of {self.user.username} on {self.tutorial.title}"

class Question(models.Model):
    title = models.CharField(max_length=200)
    content = models.TextField()
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='questions')
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.title


class Answer(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='answers')
    content = models.TextField()
    created_by = models.ForeignKey(User, on_delete=models.CASCADE, related_name='answers')
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"Answer to {self.question.title} by {self.created_by.username}"