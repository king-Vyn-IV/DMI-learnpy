from django.contrib import admin
from .models import Answer, Category, Question, Tutorial, Quiz, UserProgress

admin.site.register(Tutorial)
admin.site.register(Quiz)
admin.site.register(Category)
admin.site.register(UserProgress)
admin.site.register(Answer)
admin.site.register(Question)

