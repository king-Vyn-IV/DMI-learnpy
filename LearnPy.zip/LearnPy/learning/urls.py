from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    # Redirect the root URL to the login page
    path('', auth_views.LoginView.as_view(), name='login'),  # Make the login page the landing page
    
    # Other URLs
    path('tutorial/', views.tutorial_list, name='tutorial_list'),  # Root URL for tutorial list
    path('tutorial/<int:tutorial_id>/', views.tutorial_detail, name='tutorial_detail'),  # Tutorial detail view
    path('tutorial/<int:tutorial_id>/quiz/', views.tutorial_quiz, name='tutorial_quiz'),
    path('progress/', views.user_progress, name='user_progress'),
    path('signup/', views.signup, name='signup'),
    

    # Login and Logout
    path('login/', auth_views.LoginView.as_view(), name='login'),  # Django's built-in login view
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),  # Django's built-in logout view
    path('accounts/profile/', views.profile, name='profile'),
     path('search/', views.search_tutorials, name='search_tutorials'),


    path('forum/', views.question_list, name='question_list'),
    path('forum/question/<int:pk>/', views.question_detail, name='question_detail'),
    path('forum/question/new/', views.create_question, name='create_question'),
    path('forum/question/<int:pk>/answer/', views.create_answer, name='create_answer'),
    path('question/<int:pk>/', views.question_detail, name='question_detail'),
    path('answer/create/<int:pk>/', views.create_answer, name='create_answer'),
    path('question/<int:pk>/', views.question_detail, name='question_detail'),
    path('question/<int:pk>/answer/', views.create_answer, name='create_answer'),
    path('question/<int:pk>/', views.question_detail, name='question_detail'),
    path('question/<int:pk>/answer/', views.create_answer, name='create_answer'),
]
