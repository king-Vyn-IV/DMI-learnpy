from django.shortcuts import redirect, render, get_object_or_404
from django.contrib.auth.decorators import login_required

from learning.forms import AnswerForm, QuestionForm  # Import the decorator
from .models import Category, Question, Quiz, Tutorial, UserProgress
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate
from django.shortcuts import render, redirect


# View to list all tutorials
@login_required  # Ensures only logged-in users can access the tutorials list
def tutorial_list(request):
    tutorials = Tutorial.objects.all()
    user_progress = {tutorial.id: UserProgress.objects.filter(user=request.user, tutorial=tutorial).first() for tutorial in tutorials}
    return render(request, 'learning/tutorial_list.html', {'tutorials': tutorials, 'user_progress': user_progress})

# View to display a single tutorial's details
@login_required  # Ensures only logged-in users can access tutorial details
def tutorial_detail(request, tutorial_id):
    tutorial = get_object_or_404(Tutorial, id=tutorial_id)
    return render(request, 'learning/tutorial_detail.html', {'tutorial': tutorial})

# Display a quiz for a specific tutorial
@login_required  # Ensures only logged-in users can access the quiz
def tutorial_quiz(request, tutorial_id):
    tutorial = get_object_or_404(Tutorial, id=tutorial_id)
    quizzes = Quiz.objects.filter(tutorial=tutorial)

    if request.method == 'POST':
        score = 0
        for quiz in quizzes:
            selected_answer = request.POST.get(f"question_{quiz.id}")
            if selected_answer == quiz.correct_option:
                score += 1
        # Save the user's progress
        user_progress, created = UserProgress.objects.get_or_create(user=request.user, tutorial=tutorial)
        user_progress.score = score
        user_progress.completed = True
        user_progress.save()
        return render(request, 'learning/quiz_result.html', {'score': score, 'total': quizzes.count()})

    return render(request, 'learning/tutorial_quiz.html', {'tutorial': tutorial, 'quizzes': quizzes})

# View to display user progress
@login_required  # Ensures only logged-in users can access their progress
def user_progress(request):
    user_progress_list = UserProgress.objects.filter(user=request.user)
    return render(request, 'learning/user_progress.html', {'user_progress_list': user_progress_list})

# View to handle user signup
def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()
    return render(request, 'registration/signup.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('tutorial_list')  # Redirect to the tutorial list after successful login
    else:
        form = AuthenticationForm()
    return render(request, 'registration/login.html', {'form': form})

def profile(request):
    # You can retrieve the user info or add any other logic here
    return render(request, 'accounts/profile.html')


def search_tutorials(request):
    query = request.GET.get('q', '')  # Capture the search query
    tutorials = Tutorial.objects.filter(title__icontains=query) if query else []
    return render(request, 'search_results.html', {'tutorials': tutorials, 'search_query': query})

def question_list(request):
    questions = Question.objects.all().order_by('-created_at')
    return render(request, 'forum/question_list.html', {'questions': questions})

def question_detail(request, pk):
    question = get_object_or_404(Question, pk=pk)
    answers = question.answers.all()
    return render(request, 'forum/question_detail.html', {'question': question, 'answers': answers})

@login_required
def create_question(request):
    if request.method == "POST":
        form = QuestionForm(request.POST)
        if form.is_valid():
            question = form.save(commit=False)
            question.created_by = request.user
            question.save()
            return redirect('question_list')
    else:
        form = QuestionForm()
    return render(request, 'forum/create_question.html', {'form': form})


@login_required
def create_answer(request, pk):
    question = get_object_or_404(Question, pk=pk)
    if request.method == 'POST':
        form = AnswerForm(request.POST)
        if form.is_valid():
            answer = form.save(commit=False)
            answer.question = question
            answer.created_by = request.user
            answer.save()
            return redirect('question_detail', pk=question.pk)
    else:
        form = AnswerForm()

    return render(request, 'forum/answer_form.html', {
        'question': question,
        'form': form,
    })


